from fluxutils.log import TestLogger

TestLogger().run_tests()